importScripts('https://www.gstatic.com/firebasejs/8.9.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.9.0/firebase-messaging.js');
importScripts('https://www.gstatic.com/firebasejs/8.9.0/firebase-firestore.js');

// Initialize the Firebase app in the service worker by passing in
// your app's Firebase config object.
// https://firebase.google.com/docs/web/setup#config-object
var firebaseConfig = {
    apiKey: "AIzaSyBavhDTkzxeaUK1eDyjgNR2gzhhjcwz3CA",
    authDomain: "healthpro-bea14.firebaseapp.com",
    databaseURL: "https://healthpro-bea14-default-rtdb.firebaseio.com",
    projectId: "healthpro-bea14",
    storageBucket: "healthpro-bea14.appspot.com",
    messagingSenderId: "792921615647",
    appId: "1:792921615647:web:51d47ab08a70e43f1dd42a",
    measurementId: "G-EZ37WLJ2NQ"
  };
  
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

// Retrieve an instance of Firebase Messaging so that it can handle background
// messages.
const messaging = firebase.messaging();
messaging.onBackgroundMessage((payload) => {
    console.log('[firebase-messaging-sw.js] Received background message ', payload);
    
  
    
      const channel = new BroadcastChannel('sw-messages');
      channel.postMessage(
        payload
      );

  });