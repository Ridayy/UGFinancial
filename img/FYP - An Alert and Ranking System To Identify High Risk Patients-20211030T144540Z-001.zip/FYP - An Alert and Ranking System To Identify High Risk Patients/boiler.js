<script> 
 
const db = firebase.firestore();
const userName = document.getElementById("userName");
const specialization = document.getElementById("specialization");
let doctorId = '';

function performLogout(){
    firebase.auth().signOut();
}

function updateUserInfo(userId){
    if(userId){
        doctorId = userId;
        var docRef = db.collection("users").doc(userId);
        docRef.get().then((doc) => {
            if (doc.exists) {
                userName.textContent = doc.data().name;
                specialization.textContent = doc.data().specialization;
            } else {
                console.log("No such document!");
            }
        }).catch((error) => {
            alert(error);
        });
    }

}

$('#userLogout').click(function(e){
    e.preventDefault();
    performLogout();
});


firebase.auth().onAuthStateChanged(function(user) {
    if(user){
        updateUserInfo(user.uid);
    }else {
        window.location.href = "./";
    }
});
</script>