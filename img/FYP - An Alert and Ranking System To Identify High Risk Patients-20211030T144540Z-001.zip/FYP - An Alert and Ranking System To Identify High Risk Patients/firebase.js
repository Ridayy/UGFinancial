var firebaseConfig = {
    apiKey: "AIzaSyBavhDTkzxeaUK1eDyjgNR2gzhhjcwz3CA",
    authDomain: "healthpro-bea14.firebaseapp.com",
    databaseURL: "https://healthpro-bea14-default-rtdb.firebaseio.com",
    projectId: "healthpro-bea14",
    storageBucket: "healthpro-bea14.appspot.com",
    messagingSenderId: "792921615647",
    appId: "1:792921615647:web:51d47ab08a70e43f1dd42a",
    measurementId: "G-EZ37WLJ2NQ"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();