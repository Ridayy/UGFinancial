const firebase = require("firebase/app").default;
require("firebase/database");
const plivo = require("plivo");
const FCM = require("fcm-push");
const fcm = new FCM(
  "AAAAuJ3PrR8:APA91bFTOf91KpUDRmOPtgFVltTICgLfuLkhbEac926jGCxbrbfWw8QfXfsi1cmJP8JDUZCyAWEz6lpPRLvLeRhj4dmVkmmap6gGkeRZKP_IiP2hbR-KB5SAKDIBWgM72MBNObIl_EWl"
);

const app = firebase.initializeApp({
  apiKey: "AIzaSyBavhDTkzxeaUK1eDyjgNR2gzhhjcwz3CA",
  authDomain: "healthpro-bea14.firebaseapp.com",
  databaseURL: "https://healthpro-bea14-default-rtdb.firebaseio.com",
  projectId: "healthpro-bea14",
  storageBucket: "healthpro-bea14.appspot.com",
  messagingSenderId: "792921615647",
  appId: "1:792921615647:web:51d47ab08a70e43f1dd42a",
  measurementId: "G-EZ37WLJ2NQ",
});

const maxValues = {
  heartrate: 130,
  spo2: 100,
  temperature: 39,
};

const minValues = {
  heartrate: 40,
  spo2: 80,
  temperature: 25,
};

let lastAlertTimestamp = 0;

console.log("Listening to incoming data...");

app
  .database()
  .ref("data")
  .on("value", (snap) => {
    const jsonValues = snap.val();
    console.log(jsonValues);
    let doAlert = false;
    if (
      jsonValues.heartrate > maxValues.heartrate ||
      jsonValues.heartrate < minValues.heartrate
    ) {
      doAlert = true;
    }

    if (jsonValues.spo2 > maxValues.spo2 || jsonValues.spo2 < minValues.spo2) {
      doAlert = true;
    }

    if (
      jsonValues.temperature > maxValues.temperature ||
      jsonValues.temperature < minValues.temperature
    ) {
      doAlert = true;
    }
    const currenTime = Date.now() / 1000;
    const nextAlertTime = lastAlertTimestamp + 300;
    if (doAlert && currenTime > nextAlertTime) {
      lastAlertTimestamp = Date.now() / 1000;
      console.log("Alerting Doctor...");
      const client = new plivo.Client(
        "MAMTE2Y2EWZJUZYZI0YW",
        "MWZhZWVlZTA1ZDg5OWJjOWMzZTFjYjA0MzEyYTAy"
      );
      // Un comment when you wanna send SMS.
      client.messages.create(
        "HEALTHPRO",
        "+923233046737",
        "Alert!! Abnormal behaviour identified for patient."
      );
      sendPushNotification();
    }
  });

function sendPushNotification() {
  const message = {
    to: "/topics/notifyDoctor",
    notification: {
      title: "Patient Alert",
      body: "There are abnormal values detected.",
      content_available: true,
      priority: "high",
    },
  };

  fcm.send(message, (err, response) => {
    if (err) {
      console.log("Something has gone wrong!", err);
    } else {
      console.log("Successfully sent with response: ", response);
    }
  });
}
